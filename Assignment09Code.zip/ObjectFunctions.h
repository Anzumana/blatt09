#ifndef OBJECT_FUNCTIONS_H
#define OBJECT_FUNCTIONS_H

#include "Object.h"

char *toCString(void *obj);
char *typeName(void *o);
char *toCStringTyped(void *o);

#endif
